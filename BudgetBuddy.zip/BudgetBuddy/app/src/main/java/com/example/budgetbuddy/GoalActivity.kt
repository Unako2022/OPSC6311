package com.example.budgetbuddy

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.budgetbuddy.R
import com.example.budgetbuddy.data.AppDatabase
import com.example.budgetbuddy.model.Goal
import kotlinx.coroutines.launch

class GoalActivity : AppCompatActivity() {

    private lateinit var etGoalAmount: EditText
    private lateinit var btnSetGoal: Button
    private lateinit var tvCurrentGoal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal)

        etGoalAmount = findViewById(R.id.etGoalAmount)
        btnSetGoal = findViewById(R.id.btnSetGoal)
        tvCurrentGoal = findViewById(R.id.tvCurrentGoal)

        loadCurrentGoal()

        btnSetGoal.setOnClickListener {
            val amountStr = etGoalAmount.text.toString().trim()
            val amount = amountStr.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val dao = AppDatabase.getDatabase(this@GoalActivity).goalDao()
                dao.clearGoals() // assuming only one goal allowed
                dao.insertGoal(Goal(amount = amount))
                runOnUiThread {
                    Toast.makeText(this@GoalActivity, "Goal set", Toast.LENGTH_SHORT).show()
                    loadCurrentGoal()
                    etGoalAmount.text.clear()
                }
            }
        }
    }

    private fun loadCurrentGoal() {
        lifecycleScope.launch {
            val dao = AppDatabase.getDatabase(this@GoalActivity).goalDao()
            val goal = dao.getGoal()
            runOnUiThread {
                tvCurrentGoal.text = if (goal != null) {
                    "Current Goal: $${goal.amount}"
                } else {
                    "No goal set"
                }
            }
        }
    }
}
