package com.example.budgetbuddy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.budgetbuddy.R
import com.example.budgetbuddy.model.Expense
import android.graphics.BitmapFactory

class ExpenseReportAdapter(private val expenses: List<Expense>) : RecyclerView.Adapter<ExpenseReportAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        val tvAmount: TextView = itemView.findViewById(R.id.tvAmount)
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val ivPhoto: ImageView = itemView.findViewById(R.id.ivExpensePhoto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense_report, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = expenses.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val expense = expenses[position]
        
        holder.tvDescription.text = expense.description
        holder.tvAmount.text = "$${String.format("%.2f", expense.amount)}"
        holder.tvDate.text = expense.date
        holder.tvTime.text = "${expense.startTime} - ${expense.endTime}"

        // Handle photo display
        expense.photo?.let {
            holder.ivPhoto.visibility = View.VISIBLE
            try {
                val bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
                holder.ivPhoto.setImageBitmap(bitmap)
            } catch (e: Exception) {
                holder.ivPhoto.visibility = View.GONE
            }
        } ?: run {
            holder.ivPhoto.visibility = View.GONE
        }
    }
}
