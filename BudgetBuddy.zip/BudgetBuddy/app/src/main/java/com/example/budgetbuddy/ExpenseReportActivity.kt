package com.example.budgetbuddy

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.budgetbuddy.databinding.ActivityExpenseReportBinding

class ExpenseReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExpenseReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Expense Report"

    }
}