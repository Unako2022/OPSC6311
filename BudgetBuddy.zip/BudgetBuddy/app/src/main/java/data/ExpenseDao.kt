package com.example.budgetbuddy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.budgetbuddy.model.Expense
import com.example.budgetbuddy.model.ExpenseWithCategory


@Dao
interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense)

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    suspend fun getAllExpenses(): List<Expense>

    @Query("SELECT SUM(amount) FROM expenses")
    suspend fun getTotalExpenses(): Double?

    @Query("""
        SELECT * FROM expenses 
        WHERE date BETWEEN strftime('%s', :startDate) * 1000 AND strftime('%s', :endDate) * 1000 
        AND (:categoryId IS NULL OR categoryId = :categoryId)
    """)
    suspend fun getExpensesFiltered(
        startDate: String,
        endDate: String,
        categoryId: Int?
    ): List<Expense>


    @Query("""
    SELECT expenses.*, categories.name AS categoryName 
    FROM expenses 
    LEFT JOIN categories ON expenses.categoryId = categories.id 
    ORDER BY date DESC
""")
    suspend fun getAllExpensesWithCategory(): List<ExpenseWithCategory>


}
